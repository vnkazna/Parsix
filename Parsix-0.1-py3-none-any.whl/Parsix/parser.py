import re

def parse_it(string):

    res_shielded = re.findall(r'\\\|', string)
    count_splitter = re.findall(r'\|', string)
    
    if len(count_splitter) - len(res_shielded) != 7:
        with open('err_lines.txt', 'a+') as sv:
            sv.write(string+'\n')
        print('There are erroneous lines, it was saved to a file err_lines.txt')
    else: 
        split_values = re.split(r'\|', string)
        named_parameters = split_values.pop()
        i = 0
        for item in split_values:
            if item is not None:
                item_shield = re.search(r'\\', item[len(item)-1])
                if item_shield is not None:
                    temp = list(item)
                    temp.pop()
                    item = ''.join(temp)
                    split_values[i] = item
                    split_values[i] += '|'
                    split_values[i] += split_values[i+1]
                    del split_values[i+1]
            i+=1
    
    dict_keys = ['CollectorType', 'Eventype', 'OS', 'EventTitle', 'Level', 'Details', 'Notes']
    output_dict = dict(zip(dict_keys, split_values))
    print(output_dict)